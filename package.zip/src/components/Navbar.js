import { NavLink } from "react-router-dom";

const activeLink = ({ isActive }) => isActive ? 'active-link' : '';

const Navbar = () => {
  return (
    <nav>
      <ul>
        <li><NavLink to="/product-list" className={activeLink({ isActive: true })}>Products</NavLink></li>
        <li><NavLink to="/posts" className={activeLink({ isActive: true })}>basket of goods</NavLink></li>
      </ul>
    </nav>
  );
}

export default Navbar;
