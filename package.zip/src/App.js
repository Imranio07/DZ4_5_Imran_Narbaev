import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import ProductList from "./productList";

const routes = {
  posts: "/posts",
};

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Layout />} />
        <Route path="product-list" element={<ProductList />} />
      </Routes>
    </>
  );
}

export default App;
