export const INCREMENT = 'INCREMENT';
