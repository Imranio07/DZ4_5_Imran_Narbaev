import {INCREMENT} from "./types";

export function incrementShop() {
    return{
        type: INCREMENT
    }
}
