import {createStore} from 'redux'

const initialState = []

const reducer=(state=initialState,action) => {
    console.log('reducer>', action)
    const {type, payload} = action
    const id =1
     const name = 'tth'
    switch(type) {
        case 'INCREMENT':
            return {
        ...state,
        buy: [...state.buy, action.payload],
      };
        default:
            return state;
    }
    return state;
}
const store = createStore(reducer);
export default store;